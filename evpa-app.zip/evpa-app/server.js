'use strict';
/**
 * EVPA — servidor do Professor IA.
 *
 * - Sem dependências externas (Node 18+).
 * - Provedor de IA: Groq (GROQ_API_KEY) ou Anthropic (ANTHROPIC_API_KEY). Se as duas existirem, usa a Groq
 *   (ou a que estiver em AI_PROVIDER).
 * - As chaves são lidas SOMENTE de variáveis de ambiente, no servidor.
 *   Nunca são enviadas ao navegador, gravadas em arquivo servido ou escritas nos logs.
 * - O navegador só fala com /api/chat (mesma origem). O prompt do professor é montado aqui.
 */
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { buildSystemPrompt, DISCIPLINES } = require('./public/prompt.js');

const PUBLIC_DIR = path.join(__dirname, 'public');

// ---------- .env (apenas para desenvolvimento local; nunca versionar) ----------
function loadDotEnv(file) {
  let raw;
  try { raw = fs.readFileSync(file, 'utf8'); } catch { return; }
  for (const line of raw.split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z0-9_]+)\s*=\s*(.*?)\s*$/);
    if (!m) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (process.env[m[1]] === undefined) process.env[m[1]] = v;
  }
}
loadDotEnv(path.join(__dirname, '.env'));

// ---------- configuração (lida a cada uso; as chaves NÃO entram aqui) ----------
const envKey = (name) => (typeof process.env[name] === 'string' && process.env[name].trim()) || '';
function provider() {
  const want = (process.env.AI_PROVIDER || '').toLowerCase();
  if (want === 'groq' || want === 'anthropic') return want;
  if (envKey('GROQ_API_KEY')) return 'groq';
  if (envKey('ANTHROPIC_API_KEY')) return 'anthropic';
  return null;
}
const hasKey = () => {
  const p = provider();
  return p === 'groq' ? !!envKey('GROQ_API_KEY') : p === 'anthropic' ? !!envKey('ANTHROPIC_API_KEY') : false;
};
const cfg = () => ({
  port: Number(process.env.PORT) || 3000,
  maxTokens: Number(process.env.MAX_TOKENS) || (provider() === 'groq' ? 1500 : 2000),
  rateLimit: Number(process.env.RATE_LIMIT_PER_MIN) || 20,
  trustProxy: process.env.TRUST_PROXY === '1',
  timeoutMs: Number(process.env.UPSTREAM_TIMEOUT_MS) || 50000,
  // Groq (API compatível com OpenAI). Modelos mudam com o tempo: ajuste pelas variáveis se necessário.
  groqUrl: process.env.GROQ_API_URL || 'https://api.groq.com/openai/v1/chat/completions',
  groqModel: process.env.GROQ_MODEL || 'llama-3.3-70b-versatile',
  groqVisionModel: process.env.GROQ_VISION_MODEL || 'meta-llama/llama-4-scout-17b-16e-instruct',
  // Anthropic
  apiUrl: process.env.ANTHROPIC_API_URL || 'https://api.anthropic.com/v1/messages',
  model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
});

// ---------- limites de entrada ----------
const MAX_BODY_BYTES = 8 * 1024 * 1024;       // inclui imagem em base64
const MAX_HISTORY = 20;                        // mensagens de contexto enviadas ao Claude
const MAX_MESSAGE_CHARS = 12000;               // por mensagem (respostas longas do professor cabem)
const MAX_IMAGE_B64_CHARS = 6 * 1024 * 1024;
const IMAGE_TYPES = new Set(['image/jpeg', 'image/png', 'image/gif', 'image/webp']);

class HttpError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}

// ---------- utilitários de resposta ----------
function securityHeaders(res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('Content-Security-Policy',
    "default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; " +
    "font-src https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
}
function sendJson(res, status, obj, extra) {
  if (res.headersSent) return;
  const body = JSON.stringify(obj);
  res.writeHead(status, Object.assign({
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store',
  }, extra || {}));
  res.end(body);
}
const errBody = (code, message) => ({ error: { code, message } });

function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const declared = Number(req.headers['content-length']);
    if (declared > limit) return reject(new HttpError(413, 'too_large', 'A mensagem ou a imagem é grande demais.'));
    let size = 0, over = false;
    const chunks = [];
    req.on('data', (c) => {
      if (over) return;
      size += c.length;
      if (size > limit) { over = true; chunks.length = 0; return reject(new HttpError(413, 'too_large', 'A mensagem ou a imagem é grande demais.')); }
      chunks.push(c);
    });
    req.on('end', () => { if (!over) resolve(Buffer.concat(chunks).toString('utf8')); });
    req.on('error', reject);
  });
}

// ---------- validação e montagem das mensagens ----------
function normalizeMessages(raw) {
  if (!Array.isArray(raw) || raw.length === 0) throw new HttpError(400, 'bad_messages', 'Envie pelo menos uma mensagem.');
  const out = [];
  for (const m of raw.slice(-MAX_HISTORY)) {
    if (!m || (m.role !== 'user' && m.role !== 'assistant') || typeof m.content !== 'string') {
      throw new HttpError(400, 'bad_messages', 'Formato de mensagens inválido.');
    }
    const text = m.content.trim();
    if (!text) continue;
    if (text.length > MAX_MESSAGE_CHARS) throw new HttpError(400, 'message_too_long', 'Mensagem muito longa. Tente resumir sua pergunta.');
    const last = out[out.length - 1];
    if (last && last.role === m.role) last.content += '\n\n' + text;   // a API exige alternância
    else out.push({ role: m.role, content: text });
  }
  while (out.length && out[0].role !== 'user') out.shift();            // a API exige começar pelo aluno
  if (!out.length || out[out.length - 1].role !== 'user') {
    throw new HttpError(400, 'bad_messages', 'A última mensagem precisa ser do aluno.');
  }
  return out;
}

function validateImage(img) {
  if (img === undefined || img === null) return null;
  if (typeof img !== 'object' || !IMAGE_TYPES.has(img.media_type) || typeof img.data !== 'string' ||
      !img.data.length || img.data.length > MAX_IMAGE_B64_CHARS || !/^[A-Za-z0-9+/]+={0,2}$/.test(img.data)) {
    throw new HttpError(400, 'bad_image', 'Imagem inválida. Use JPG, PNG, WEBP ou GIF.');
  }
  return { media_type: img.media_type, data: img.data };
}

// ---------- chamada ao provedor de IA (Groq ou Anthropic) ----------
const FALLBACK_REPLY = 'Desculpe, não consegui montar uma resposta para isso. Pode perguntar de outro jeito?';

function mapUpstreamError(label, status, data) {
  const e = (data && data.error) || {};
  const msg = e.message || '';
  const keyVar = label === 'groq' ? 'GROQ_API_KEY' : 'ANTHROPIC_API_KEY';
  const modelVar = label === 'groq' ? 'GROQ_MODEL / GROQ_VISION_MODEL' : 'ANTHROPIC_MODEL';
  console.error(`[${label}] HTTP ${status} ${e.type || ''} ${msg}`.trim());      // só diagnóstico; nunca a chave
  const unavailable = () => new HttpError(503, 'ai_unavailable', 'O Professor IA está indisponível no momento. Avise o responsável pelo site.');
  if (status === 401 || status === 403) {
    console.error(`[${label}] Verifique ${keyVar} (inválida ou sem permissão).`);
    return unavailable();
  }
  if (status === 429) return new HttpError(429, 'rate_limited', 'O Professor IA está recebendo muitas perguntas agora. Tente de novo em alguns segundos.');
  if (status === 404 || /decommission|does not exist|no longer supported|model_not_found/i.test(`${msg} ${e.code || ''}`)) {
    console.error(`[${label}] Modelo indisponível: ajuste ${modelVar}.`);
    return unavailable();
  }
  if (/credit balance|insufficient/i.test(msg)) {
    console.error(`[${label}] Saldo/créditos insuficientes na conta do provedor.`);
    return unavailable();
  }
  if (status === 400 || status === 413 || status === 422) return new HttpError(502, 'bad_request', 'Não consegui processar essa pergunta. Tente reformular ou enviar uma imagem menor.');
  return new HttpError(503, 'ai_busy', 'O Professor IA está ocupado agora. Tente de novo em instantes.');
}

async function postJson(label, url, headers, body) {
  let res;
  try {
    res = await fetch(url, {
      method: 'POST',
      headers: Object.assign({ 'content-type': 'application/json' }, headers),
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(cfg().timeoutMs),
    });
  } catch (e) {
    if (e && (e.name === 'TimeoutError' || e.name === 'AbortError')) {
      throw new HttpError(504, 'timeout', 'O Professor IA demorou demais para responder. Tente de novo.');
    }
    console.error(`[${label}] falha de rede:`, e && e.message);
    throw new HttpError(502, 'upstream_unreachable', 'Não consegui falar com o Professor IA agora. Tente de novo em instantes.');
  }
  const data = await res.json().catch(() => null);
  if (!res.ok) throw mapUpstreamError(label, res.status, data);
  return data;
}

async function askGroq({ system, messages, image }) {
  const c = cfg();
  if (image && image.data.length > 4 * 1024 * 1024) {     // limite de imagem em base64 da Groq
    throw new HttpError(400, 'image_too_large', 'Essa foto é grande demais. Tente uma menor.');
  }
  const msgs = [{ role: 'system', content: system }].concat(messages.map((m) => ({ role: m.role, content: m.content })));
  if (image) {
    const last = msgs[msgs.length - 1];
    last.content = [
      { type: 'text', text: last.content },
      { type: 'image_url', image_url: { url: `data:${image.media_type};base64,${image.data}` } },
    ];
  }
  const data = await postJson('groq', c.groqUrl, { authorization: 'Bearer ' + envKey('GROQ_API_KEY') }, {
    model: image ? c.groqVisionModel : c.groqModel,
    messages: msgs,
    max_completion_tokens: c.maxTokens,
    temperature: 0.6,
  });
  const choice = data && data.choices && data.choices[0];
  const text = String((choice && choice.message && choice.message.content) || '')
    .replace(/<think>[\s\S]*?<\/think>/g, '').trim();
  return { reply: text || FALLBACK_REPLY, truncated: !!(choice && choice.finish_reason === 'length') };
}

async function askClaude({ system, messages, image }) {
  const c = cfg();
  const msgs = messages.map((m) => ({ role: m.role, content: m.content }));
  if (image) {
    const last = msgs[msgs.length - 1];
    last.content = [
      { type: 'image', source: { type: 'base64', media_type: image.media_type, data: image.data } },
      { type: 'text', text: last.content },
    ];
  }
  const data = await postJson('anthropic', c.apiUrl, {
    'x-api-key': envKey('ANTHROPIC_API_KEY'),
    'anthropic-version': '2023-06-01',
  }, { model: c.model, max_tokens: c.maxTokens, system, messages: msgs });
  const text = ((data && data.content) || []).filter((b) => b && b.type === 'text').map((b) => b.text).join('').trim();
  return { reply: text || FALLBACK_REPLY, truncated: !!(data && data.stop_reason === 'max_tokens') };
}

const ask = (args) => (provider() === 'groq' ? askGroq(args) : askClaude(args));

// ---------- rotas ----------
function createServer() {
  const hits = new Map();   // ip -> timestamps (limite simples em memória)
  const sweeper = setInterval(() => {
    const cutoff = Date.now() - 60000;
    for (const [ip, arr] of hits) { const k = arr.filter((t) => t > cutoff); if (k.length) hits.set(ip, k); else hits.delete(ip); }
  }, 60000);
  sweeper.unref();

  function clientIp(req) {
    if (cfg().trustProxy) {
      const xf = req.headers['x-forwarded-for'];
      if (typeof xf === 'string' && xf) return xf.split(',')[0].trim();
    }
    return req.socket.remoteAddress || 'unknown';
  }
  function allow(ip) {
    const now = Date.now(), cutoff = now - 60000;
    const arr = (hits.get(ip) || []).filter((t) => t > cutoff);
    if (arr.length >= cfg().rateLimit) { hits.set(ip, arr); return false; }
    arr.push(now); hits.set(ip, arr); return true;
  }

  async function handleChat(req, res) {
    const started = Date.now();
    if (!allow(clientIp(req))) {
      throw new HttpError(429, 'rate_limited', 'Muitas perguntas em pouco tempo. Respire um pouquinho e tente de novo em instantes.');
    }
    if (!hasKey()) {
      console.error('[config] Nenhuma chave de IA definida (GROQ_API_KEY ou ANTHROPIC_API_KEY).');
      throw new HttpError(503, 'no_key', 'O Professor IA ainda não foi configurado. Avise o responsável pelo site.');
    }
    if (!/^application\/json\b/i.test(req.headers['content-type'] || '')) {
      throw new HttpError(415, 'bad_content_type', 'Formato de envio inválido.');
    }
    let body;
    try { body = JSON.parse(await readBody(req, MAX_BODY_BYTES)); } catch (e) {
      if (e instanceof HttpError) throw e;
      throw new HttpError(400, 'bad_json', 'Não entendi o que foi enviado.');
    }
    if (!body || typeof body !== 'object') throw new HttpError(400, 'bad_json', 'Não entendi o que foi enviado.');

    const messages = normalizeMessages(body.messages);
    const image = validateImage(body.image);
    const discipline = Object.prototype.hasOwnProperty.call(DISCIPLINES, body.discipline) ? body.discipline : null;
    const system = buildSystemPrompt({ discipline, name: body.studentName });

    const out = await ask({ system, messages, image });
    console.log(`[chat] 200 ${provider()} ${Date.now() - started}ms msgs=${messages.length}${image ? ' img' : ''}`);   // sem conteúdo dos alunos
    sendJson(res, 200, out);
  }

  const MIME = {
    '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
    '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon', '.json': 'application/json; charset=utf-8', '.txt': 'text/plain; charset=utf-8',
  };
  function notFound(res) {
    securityHeaders(res);
    res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('Não encontrado');
  }
  function serveStatic(pathname, req, res) {
    let rel;
    try { rel = decodeURIComponent(pathname); } catch { return notFound(res); }
    if (rel.includes('\0')) return notFound(res);
    if (rel === '/') rel = '/index.html';
    if (rel.split('/').some((seg) => seg.startsWith('.'))) return notFound(res);   // .env, .git etc.
    const full = path.join(PUBLIC_DIR, rel);
    if (!full.startsWith(PUBLIC_DIR + path.sep)) return notFound(res);              // path traversal
    const type = MIME[path.extname(full).toLowerCase()];
    if (!type) return notFound(res);
    fs.readFile(full, (e, buf) => {
      if (e) return notFound(res);
      res.writeHead(200, {
        'Content-Type': type,
        'Content-Length': buf.length,
        'Cache-Control': type.startsWith('text/html') ? 'no-cache' : 'public, max-age=3600',
      });
      res.end(req.method === 'HEAD' ? undefined : buf);
    });
  }

  async function handle(req, res) {
    securityHeaders(res);
    const { pathname } = new URL(req.url, 'http://localhost');
    if (pathname === '/api/health') {
      if (req.method !== 'GET') throw new HttpError(405, 'method_not_allowed', 'Método não permitido.');
      return sendJson(res, 200, { ok: true, aiConfigured: hasKey(), provider: hasKey() ? provider() : null });   // nunca a chave
    }
    if (pathname === '/api/chat') {
      if (req.method !== 'POST') throw new HttpError(405, 'method_not_allowed', 'Método não permitido.');
      return handleChat(req, res);
    }
    if (pathname.startsWith('/api/')) throw new HttpError(404, 'not_found', 'Rota não encontrada.');
    if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'method_not_allowed', 'Método não permitido.');
    return serveStatic(pathname, req, res);
  }

  return http.createServer((req, res) => {
    handle(req, res).catch((err) => {
      if (err instanceof HttpError) {
        const extra = err.status === 405 ? { Allow: 'GET, POST' } : (err.status === 413 ? { Connection: 'close' } : undefined);
        return sendJson(res, err.status, errBody(err.code, err.message), extra);
      }
      console.error('[erro]', err && err.message);
      sendJson(res, 500, errBody('internal', 'Erro interno. Tente novamente.'));
    });
  });
}

module.exports = { createServer, normalizeMessages };

if (require.main === module) {
  const c = cfg();
  createServer().listen(c.port, () => {
    console.log(`EVPA rodando em http://localhost:${c.port}`);
    console.log(hasKey()
      ? `Professor IA: provedor ${provider()} configurado.`
      : 'ATENÇÃO: nenhuma chave de IA definida. Defina GROQ_API_KEY (ou ANTHROPIC_API_KEY): veja o README.');
  });
}
