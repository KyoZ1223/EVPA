# EVPA — Estudo Virtual de Pesquisa e Aprendizagem

Site educacional com o **Professor IA**: um professor particular que responde de verdade, explica passo a passo,
lembra o contexto da conversa e lê fotos de atividades.

A chave da IA fica **somente no servidor** (variável de ambiente). O navegador nunca a vê.

## Como funciona

```
Navegador (public/index.html)  ──►  /api/chat  (server.js)  ──►  Groq (ou Anthropic)
                                         ▲
                                  chave em variável de ambiente
```

- `server.js`: servidor sem dependências (Node 18+). Monta o prompt do professor, valida tudo e chama a IA.
- `public/`: o site (design do EVPA) e o `prompt.js` com as instruções do Professor IA.
- `test/`: testes automáticos (`npm test`).

## Matérias e assuntos

O Professor IA conhece as 6 matérias e todos os assuntos do site (38 no total) e dá uma aula padrão
(ideia principal, passo a passo, exemplo resolvido, resumo e mini exercício) quando o aluno clica em um assunto.
Os assuntos ficam em `DISCS` no `public/index.html` e em `CURRICULUM` no `public/prompt.js`.
Se você adicionar ou renomear um assunto, atualize os dois: o teste "currículo" (`npm test`) avisa se ficarem diferentes.

## Rodar no seu computador

1. Instale o [Node.js](https://nodejs.org) 18 ou mais novo.
2. Nesta pasta, crie o arquivo `.env` a partir do exemplo:
   ```
   cp .env.example .env
   ```
3. Abra o `.env` e cole sua chave da Groq depois de `GROQ_API_KEY=` (chaves começam com `gsk_`;
   crie em https://console.groq.com/keys).
4. Inicie:
   ```
   npm start
   ```
5. Abra http://localhost:3000. Em **Configurações**, o item "Professor IA" fica verde quando está tudo certo.

## Colocar na internet (para qualquer pessoa abrir e perguntar)

Quem abrir o site só digita o nome e faz a pergunta: **não precisa de chave, conta nem configuração**.
A chave fica guardada no servidor, nunca na página.

Exemplo com o Render (gratuito):

1. Suba esta pasta para um repositório no GitHub. O `.env` está no `.gitignore` e **não deve** ser enviado.
2. No Render: *New → Blueprint*, escolha o repositório. O arquivo `render.yaml` já configura tudo.
3. Quando o Render pedir `GROQ_API_KEY`, cole sua chave da Groq e clique em *Deploy*.
4. Em alguns minutos o endereço `https://evpa-xxxx.onrender.com` abre o site. Em **Configurações** do site, o item
   "Professor IA" fica verde quando está tudo certo.

No plano gratuito do Render o site "dorme" depois de um tempo parado e a primeira visita pode demorar cerca de 1 minuto.
Railway, Fly.io e outros funcionam do mesmo jeito: Node 18+, comando `node server.js` e a variável `GROQ_API_KEY`.

> Nunca coloque a chave dentro de `public/` nem em qualquer arquivo do site: quem abre o site consegue ler e copiar.

## Variáveis de ambiente

| Variável | Para quê | Padrão |
|---|---|---|
| `GROQ_API_KEY` | Chave da Groq (**obrigatória** para usar a Groq) | – |
| `GROQ_MODEL` | Modelo de texto | `llama-3.3-70b-versatile` |
| `GROQ_VISION_MODEL` | Modelo usado quando o aluno envia foto | `meta-llama/llama-4-scout-17b-16e-instruct` |
| `MAX_TOKENS` | Tamanho máximo da resposta | `1500` (Groq) / `2000` (Anthropic) |
| `RATE_LIMIT_PER_MIN` | Perguntas por minuto, por visitante | `20` |
| `TRUST_PROXY` | `1` quando está atrás de proxy (Render, Railway...) | – |
| `AI_PROVIDER` | `groq` ou `anthropic` (escolhe automaticamente pela chave existente) | – |
| `ANTHROPIC_API_KEY`, `ANTHROPIC_MODEL` | Alternativa: usar o Claude | `claude-sonnet-5-5` |

Os nomes de modelos da Groq mudam de tempos em tempos. Se o Professor IA parar de responder e o log do servidor
disser "Modelo indisponível", troque `GROQ_MODEL` / `GROQ_VISION_MODEL` por um modelo atual de
https://console.groq.com/docs/models.

## Segurança e privacidade

- A chave existe só em variável de ambiente, nunca em código, página, `localStorage` ou resposta da API.
  (Versões antigas guardavam uma chave no navegador. O site novo apaga essa chave ao abrir.)
- O prompt do professor é montado no servidor; o navegador não consegue trocá-lo.
- Limites: tamanho de mensagem, 20 mensagens de contexto, imagens só JPG/PNG/WEBP/GIF, limite por minuto por visitante.
- Os logs registram só status e tempo, **nunca** o conteúdo das perguntas dos alunos.
- Todo texto (do aluno e da IA) é escapado na tela, o que evita injeção de HTML.
- **Se uma chave já apareceu em um chat, e-mail ou print, gere uma nova no painel do provedor e apague a antiga.**
- Defina um limite de gasto/uso no painel do provedor. O plano gratuito da Groq tem limites por minuto e por dia;
  quando estoura, o aluno vê um aviso amigável.

## Testes

```
npm test
```

Os testes usam um "provedor falso" local (não gastam chave nem precisam de internet) e conferem: contexto da conversa,
fotos, erros, limites, path traversal e que a chave nunca vaza.

## O que ainda não está incluído

Histórico de conversas e progresso ficam no navegador do aluno. Login e banco de dados (Supabase) são o próximo passo.
